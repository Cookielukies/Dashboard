const baseLogistica = [
    { id_entrega: 301, transportadora: 'RotaMax', regiao: 'Sudeste', prazo_days: 3, dias_reais: 7 },
    { id_entrega: 302, transportadora: 'ViaCargo', regiao: 'Sul', prazo_days: 5, dias_reais: 5 },
    { id_entrega: 303, transportadora: 'FlashLog', regiao: 'Nordeste', prazo_days: 4, dias_reais: 9 },
    { id_entrega: 304, transportadora: 'RotaMax', regiao: 'Norte', prazo_days: 6, dias_reais: 4 },
    { id_entrega: 305, transportadora: 'ViaCargo', regiao: 'Centro-Oeste', prazo_days: 2, dias_reais: 6 },
    { id_entrega: 306, transportadora: 'FlashLog', regiao: 'Sul', prazo_days: 5, dias_reais: 12 },
    { id_entrega: 307, transportadora: 'RotaMax', regiao: 'Sul', prazo_days: 6, dias_reais: 9 },
    { id_entrega: 308, transportadora: 'ViaCargo', regiao: 'Sudeste', prazo_days: 3, dias_reais: 4 },
    { id_entrega: 309, transportadora: 'FlashLog', regiao: 'Norte', prazo_days: 5, dias_reais: 5 },
    { id_entrega: 310, transportadora: 'ViaCargo', regiao: 'Nordeste', prazo_days: 4, dias_reais: 8 }
];

const dadosTratados = baseLogistica.map(registro => {
    const delta = registro.dias_reais - registro.prazo_days;
    const status = delta > 0 ? 'Atrasado' : 'No Prazo';
    const diasAtraso = delta > 0 ? delta : 0;
    
    let crise = 'Controlada';
    if (diasAtraso >= 5) crise = 'Crítica';
    else if (diasAtraso > 0) crise = 'Moderada';

    return { ...registro, atraso: diasAtraso, status, crise };
});

let graficoTransp = null;

function init() {
    setupMapInteraction();
    updateDashboard();
}

function resetFilters() {
    document.getElementById('filter-transportadora').value = 'all';
    document.getElementById('filter-regiao').value = 'all';
    document.getElementById('filter-status').value = 'all';
    updateDashboard();
}

function updateDashboard() {
    const fTransp = document.getElementById('filter-transportadora').value;
    const fRegiao = document.getElementById('filter-regiao').value;
    const fStatus = document.getElementById('filter-status').value;

    const dadosFiltrados = dadosTratados.filter(item => {
        const mTransp = fTransp === 'all' || item.transportadora === fTransp;
        const mRegiao = fRegiao === 'all' || item.regiao === fRegiao;
        const mStatus = fStatus === 'all' || item.status === fStatus;
        return mTransp && mRegiao && mStatus;
    });

    renderKPIs(dadosFiltrados);
    renderTable(dadosFiltrados);
    renderCharts(dadosFiltrados);
    updateMapColors(dadosFiltrados);
}

function renderKPIs(dados) {
    const total = dados.length;
    const atrasados = dados.filter(i => i.status === 'Atrasado').length;
    const indice = total > 0 ? ((atrasados / total) * 100).toFixed(1) : '0.0';
    
    const somaAtrasos = dados.reduce((acc, current) => acc + current.atraso, 0);
    const media = atrasados > 0 ? (somaAtrasos / atrasados).toFixed(1) : '0.0';

    document.getElementById('kpi-total').innerText = total;
    document.getElementById('kpi-atrasos').innerText = atrasados;
    document.getElementById('kpi-indice').innerText = `${indice}%`;
    document.getElementById('kpi-media-atraso').innerText = `${media} dias`;
}

function renderTable(dados) {
    const tbody = document.getElementById('table-body');
    tbody.innerHTML = '';

    if (dados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:var(--text-muted);">Nenhum dado encontrado para a seleção.</td></tr>`;
        return;
    }

    dados.forEach(item => {
        const tr = document.createElement('tr');
        const badgeClass = item.status === 'Atrasado' ? 'badge-danger' : 'badge-success';
        
        let dotColor = 'dot-low';
        if (item.crise === 'Crítica') dotColor = 'dot-high';
        else if (item.crise === 'Moderada') dotColor = 'dot-medium';

        tr.innerHTML = `
            <td><strong>#${item.id_entrega}</strong></td>
            <td>${item.transportadora}</td>
            <td>${item.regiao}</td>
            <td>${item.prazo_days} dias</td>
            <td>${item.dias_reais} dias</td>
            <td><span style="font-weight:bold; color: ${item.atraso > 0 ? 'var(--danger)' : 'var(--text-main)'}">${item.atraso > 0 ? '+' + item.atraso : 0}</span></td>
            <td><span class="badge ${badgeClass}">${item.status}</span></td>
            <td>
                <div class="priority-indicator">
                    <span class="dot ${dotColor}"></span>
                    <span>${item.crise}</span>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function renderCharts(dados) {
    if (graficoTransp) graficoTransp.destroy();

    const transportadoras = ['RotaMax', 'ViaCargo', 'FlashLog'];
    const metricasTransp = transportadoras.map(t => {
        const sub = dados.filter(i => i.transportadora === t);
        const total = sub.length;
        const erros = sub.filter(i => i.status === 'Atrasado').length;
        return total > 0 ? Math.round((erros / total) * 100) : 0;
    });

    const ctxT = document.getElementById('chartTransportadora').getContext('2d');
    graficoTransp = new Chart(ctxT, {
        type: 'bar',
        data: {
            labels: transportadoras,
            datasets: [{
                data: metricasTransp,
                backgroundColor: ['#805ad5', '#b7791f', '#3182ce'],
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%' } } }
        }
    });
}

// --- CONTROLE GEOGRÁFICO DO MAPA ---
function updateMapColors(dadosAtuais) {
    const regioes = ['Sul', 'Sudeste', 'Nordeste', 'Norte', 'Centro-Oeste'];
    
    regioes.forEach(regiao => {
        const path = document.getElementById(`regiao-${regiao}`);
        if (!path) return;

        const volumeAtrasos = dadosAtuais.filter(i => i.regiao === regiao && i.status === 'Atrasado').length;

        // Pinta os caminhos cartográficos reais com base no risco calculado
        if (volumeAtrasos >= 3) {
            path.style.fill = '#f56565'; // Vermelho (Sul)
        } else if (volumeAtrasos === 2) {
            path.style.fill = '#ed8936'; // Laranja (Nordeste)
        } else if (volumeAtrasos === 1) {
            path.style.fill = '#feebc8'; // Amarelo
        } else {
            path.style.fill = '#edf2f7'; // Cinza (Sem problemas ou filtrado)
        }
    });
}

function setupMapInteraction() {
    const paths = document.querySelectorAll('.map-region');
    const tooltip = document.getElementById('map-tooltip');
    const container = document.querySelector('.map-container');

    paths.forEach(path => {
        const nomeRegiao = path.getAttribute('data-region');

        path.addEventListener('mousemove', function(e) {
            const entregasRegiao = dadosTratados.filter(i => i.regiao === nomeRegiao);
            const total = entregasRegiao.length;
            const atrasados = entregasRegiao.filter(i => i.status === 'Atrasado').length;

            tooltip.innerHTML = `
                <strong style="color:#ecc94b; font-size:13px;">Região ${nomeRegiao}</strong><br/>
                Total de Envios: ${total}<br/>
                Atrasos Identificados: <span style="color:#f56565; font-weight:bold;">${atrasados}</span>
            `;

            // Calcula o posicionamento relativo ao container para evitar quebras de layout
            const rect = container.getBoundingClientRect();
            tooltip.style.opacity = '1';
            tooltip.style.left = (e.clientX - rect.left + 15) + 'px';
            tooltip.style.top = (e.clientY - rect.top + 15) + 'px';
        });

        path.addEventListener('mouseleave', function() {
            tooltip.style.opacity = '0';
        });
        
        path.addEventListener('click', function() {
            document.getElementById('filter-regiao').value = nomeRegiao;
            updateDashboard();
        });
    });
}

window.onload = init;