// LogiTrack - Dashboard de Monitoramento Logístico
// Lógica de dados, filtros, gráficos dinâmicos e simulador de tempo real

// 1. DATASET OPERACIONAL INICIAL (Conforme imagem fornecida)
let deliveries = [
  { id_entrega: 301, transportadora: 'RotaMax', regiao: 'Sudeste', prazo_dias: 3, dias_reais: 7 },
  { id_entrega: 302, transportadora: 'ViaCargo', regiao: 'Sul', prazo_dias: 5, dias_reais: 5 },
  { id_entrega: 303, transportadora: 'FlashLog', regiao: 'Nordeste', prazo_dias: 4, dias_reais: 9 },
  { id_entrega: 304, transportadora: 'RotaMax', regiao: 'Norte', prazo_dias: 6, dias_reais: 4 },
  { id_entrega: 305, transportadora: 'ViaCargo', regiao: 'Centro-Oeste', prazo_dias: 2, dias_reais: 6 },
  { id_entrega: 306, transportadora: 'FlashLog', regiao: 'Sul', prazo_dias: 5, dias_reais: 12 },
  { id_entrega: 307, transportadora: 'RotaMax', regiao: 'Sul', prazo_dias: 6, dias_reais: 9 },
  { id_entrega: 308, transportadora: 'ViaCargo', regiao: 'Sudeste', prazo_dias: 3, dias_reais: 4 },
  { id_entrega: 309, transportadora: 'FlashLog', regiao: 'Norte', prazo_dias: 5, dias_reais: 5 },
  { id_entrega: 310, transportadora: 'ViaCargo', regiao: 'Nordeste', prazo_dias: 4, dias_reais: 8 }
];

// 2. ESTADO GLOBAL DA APLICAÇÃO
let currentTheme = 'dark';
let sortColumn = 'id_entrega';
let sortDirection = 'asc'; // 'asc' ou 'desc'

// Variáveis para instâncias dos gráficos (evita duplicações na recriação)
let chartCarrierInstance = null;
let chartRegionInstance = null;
let chartStatusInstance = null;

// 3. INICIALIZAÇÃO DO DASHBOARD
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  setupEventListeners();
  suggestNextId();
  updateDashboard();
});

// 4. CONFIGURAÇÃO DE TEMAS (LIGHT / DARK)
function initTheme() {
  const themeToggle = document.getElementById('themeToggle');
  const htmlElement = document.documentElement;
  
  // Tenta ler do localStorage ou assume Dark como default
  const savedTheme = localStorage.getItem('theme') || 'dark';
  currentTheme = savedTheme;
  htmlElement.setAttribute('data-theme', currentTheme);
  updateThemeIcons();
}

function updateThemeIcons() {
  const sunIcon = document.querySelector('.sun-icon');
  const moonIcon = document.querySelector('.moon-icon');
  
  if (currentTheme === 'light') {
    sunIcon.style.display = 'block';
    moonIcon.style.display = 'none';
  } else {
    sunIcon.style.display = 'none';
    moonIcon.style.display = 'block';
  }
}

// Alternar tema e atualizar gráficos correspondentes para melhor legibilidade
document.getElementById('themeToggle').addEventListener('click', () => {
  const htmlElement = document.documentElement;
  currentTheme = currentTheme === 'light' ? 'dark' : 'light';
  htmlElement.setAttribute('data-theme', currentTheme);
  localStorage.setItem('theme', currentTheme);
  updateThemeIcons();
  
  // Atualiza as cores dos gráficos com base no novo tema
  updateDashboard();
});

// 5. EVENT LISTENERS
function setupEventListeners() {
  // Filtros de seleção
  document.getElementById('filterCarrier').addEventListener('change', updateDashboard);
  document.getElementById('filterRegion').addEventListener('change', updateDashboard);
  document.getElementById('filterStatus').addEventListener('change', updateDashboard);
  
  // Reset de filtros
  document.getElementById('resetFiltersBtn').addEventListener('click', () => {
    document.getElementById('filterCarrier').value = 'all';
    document.getElementById('filterRegion').value = 'all';
    document.getElementById('filterStatus').value = 'all';
    document.getElementById('tableSearch').value = '';
    updateDashboard();
  });

  // Busca textual
  document.getElementById('tableSearch').addEventListener('input', updateDashboard);

  // Ordenação de colunas da tabela
  document.querySelectorAll('th.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const column = th.dataset.column;
      if (sortColumn === column) {
        sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
      } else {
        sortColumn = column;
        sortDirection = 'asc';
      }
      
      // Atualiza classes visuais
      document.querySelectorAll('th.sortable').forEach(header => {
        header.classList.remove('asc', 'desc');
      });
      th.classList.add(sortDirection);
      
      updateDashboard();
    });
  });

  // Modal do simulador
  const modal = document.getElementById('simulatorModal');
  document.getElementById('openSimulatorBtn').addEventListener('click', () => {
    modal.classList.add('active');
    suggestNextId();
  });
  document.getElementById('closeSimulatorBtn').addEventListener('click', () => modal.classList.remove('active'));
  document.getElementById('cancelSimBtn').addEventListener('click', () => modal.classList.remove('active'));
  
  // Fechar clicando fora
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('active');
  });

  // Submissão do simulador
  document.getElementById('simulatorForm').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const id = parseInt(document.getElementById('simId').value);
    const transportadora = document.getElementById('simCarrier').value;
    const regiao = document.getElementById('simRegion').value;
    const prazo_dias = parseInt(document.getElementById('simDeadline').value);
    const dias_reais = parseInt(document.getElementById('simRealDays').value);
    
    // Validar ID único
    if (deliveries.some(d => d.id_entrega === id)) {
      alert(`Erro: Já existe uma entrega com o ID ${id}. Por favor, insira um ID único.`);
      return;
    }

    // Adiciona nova entrega
    deliveries.push({ id_entrega: id, transportadora, regiao, prazo_dias, dias_reais });
    
    // Feedback visual e reset
    modal.classList.remove('active');
    document.getElementById('simulatorForm').reset();
    suggestNextId();
    
    // Atualizar dashboard com novos dados simulados
    updateDashboard();
    
    // Mostrar notificação flutuante de sucesso
    showNotification(`Entrega #${id} adicionada à base operacional!`);
  });
}

// Sugerir automaticamente o próximo ID da entrega
function suggestNextId() {
  if (deliveries.length > 0) {
    const maxId = Math.max(...deliveries.map(d => d.id_entrega));
    document.getElementById('simId').value = maxId + 1;
  } else {
    document.getElementById('simId').value = 301;
  }
}

// 6. PROCESSAMENTO E RENDERIZAÇÃO DO DASHBOARD
function updateDashboard() {
  // Filtra dados com base nos seletores ativos
  const filteredData = filterData();
  
  // Ordena os dados filtrados
  const sortedData = sortData(filteredData);
  
  // Renderiza KPIs
  calculateKPIs(filteredData);
  
  // Renderiza a Tabela
  renderTable(sortedData);
  
  // Desenha os Gráficos
  renderCharts(filteredData);
}

// 7. FILTRAGEM DE DADOS
function filterData() {
  const carrierFilter = document.getElementById('filterCarrier').value;
  const regionFilter = document.getElementById('filterRegion').value;
  const statusFilter = document.getElementById('filterStatus').value;
  const searchText = document.getElementById('tableSearch').value.toLowerCase();

  return deliveries.filter(d => {
    // Cálculo do atraso para o filtro de status
    const atraso = d.dias_reais - d.prazo_dias;
    const isDelayed = atraso > 0;
    
    // Match de transportadora
    const matchCarrier = (carrierFilter === 'all' || d.transportadora === carrierFilter);
    // Match de região
    const matchRegion = (regionFilter === 'all' || d.regiao === regionFilter);
    
    // Match de status/gravidade
    let matchStatus = true;
    if (statusFilter === 'no-delay') matchStatus = !isDelayed;
    else if (statusFilter === 'delayed') matchStatus = isDelayed;
    else if (statusFilter === 'moderate-delay') matchStatus = (isDelayed && atraso <= 4);
    else if (statusFilter === 'critical-delay') matchStatus = (isDelayed && atraso > 4);

    // Match de busca (ID ou Transportadora)
    const matchSearch = (
      d.id_entrega.toString().includes(searchText) || 
      d.transportadora.toLowerCase().includes(searchText) ||
      d.regiao.toLowerCase().includes(searchText)
    );

    return matchCarrier && matchRegion && matchStatus && matchSearch;
  });
}

// 8. ORDENAÇÃO DE DADOS
function sortData(data) {
  return [...data].sort((a, b) => {
    let valA = a[sortColumn];
    let valB = b[sortColumn];
    
    // Campos virtuais para ordenação
    if (sortColumn === 'atraso') {
      valA = Math.max(0, a.dias_reais - a.prazo_dias);
      valB = Math.max(0, b.dias_reais - b.prazo_dias);
    } else if (sortColumn === 'criticidade') {
      const atrA = a.dias_reais - a.prazo_dias;
      const atrB = b.dias_reais - b.prazo_dias;
      valA = atrA <= 0 ? 0 : (atrA <= 4 ? 1 : 2);
      valB = atrB <= 0 ? 0 : (atrB <= 4 ? 1 : 2);
    }

    // Se for string, compara alfabeticamente
    if (typeof valA === 'string') {
      return sortDirection === 'asc' 
        ? valA.localeCompare(valB) 
        : valB.localeCompare(valA);
    }
    
    // Se for número
    return sortDirection === 'asc' ? valA - valB : valB - valA;
  });
}

// 9. CÁLCULO E EXIBIÇÃO DE KPIS
function calculateKPIs(data) {
  const total = data.length;
  document.getElementById('kpiTotal').innerText = total;
  
  if (total === 0) {
    document.getElementById('kpiDelayRate').innerText = '0%';
    document.getElementById('kpiTotalDetail').innerText = 'Nenhum resultado';
    document.getElementById('kpiDelayDetail').innerText = '0 atrasadas';
    document.getElementById('kpiAvgDelay').innerText = '0d';
    document.getElementById('kpiAvgDelayDetail').innerText = 'Sem atrasos no filtro';
    document.getElementById('kpiCritical').innerText = '0';
    document.getElementById('kpiCriticalDetail').innerText = '0% do total filtrado';
    return;
  }

  // Filtrar atrasadas
  const delayedDeliveries = data.filter(d => d.dias_reais > d.prazo_dias);
  const totalDelayed = delayedDeliveries.length;
  
  // Taxa de atraso
  const delayRate = (totalDelayed / total) * 100;
  document.getElementById('kpiDelayRate').innerText = `${delayRate.toFixed(0)}%`;
  document.getElementById('kpiDelayDetail').innerText = `${totalDelayed} de ${total} entregas`;
  
  // Estilizar card de taxa de atraso conforme risco
  const delayCard = document.getElementById('kpiDelayCard');
  if (delayRate > 50) {
    delayCard.style.setProperty('--kpi-color', 'var(--color-danger)');
    delayCard.style.setProperty('--kpi-bg', 'var(--color-danger-bg)');
  } else if (delayRate > 20) {
    delayCard.style.setProperty('--kpi-color', 'var(--color-warning)');
    delayCard.style.setProperty('--kpi-bg', 'var(--color-warning-bg)');
  } else {
    delayCard.style.setProperty('--kpi-color', 'var(--color-success)');
    delayCard.style.setProperty('--kpi-bg', 'var(--color-success-bg)');
  }

  // Média de atraso (considerando apenas entregas com atraso > 0 dias)
  let avgDelay = 0;
  if (totalDelayed > 0) {
    const totalDelayDays = delayedDeliveries.reduce((sum, d) => sum + (d.dias_reais - d.prazo_dias), 0);
    avgDelay = totalDelayDays / totalDelayed;
  }
  document.getElementById('kpiAvgDelay').innerText = `${avgDelay.toFixed(1)}d`;
  document.getElementById('kpiAvgDelayDetail').innerText = `Média de dias das ${totalDelayed} atrasadas`;

  // Entregas críticas (atraso > 4 dias)
  const criticalCount = data.filter(d => (d.dias_reais - d.prazo_dias) > 4).length;
  document.getElementById('kpiCritical').innerText = criticalCount;
  
  const criticalRate = (criticalCount / total) * 100;
  document.getElementById('kpiCriticalDetail').innerText = `${criticalRate.toFixed(0)}% do total no filtro`;
  
  // Detalhe das entregas totais
  document.getElementById('kpiTotalDetail').innerText = `Filtradas da base operacional`;
}

// 10. RENDERIZAÇÃO DA TABELA
function renderTable(data) {
  const tbody = document.getElementById('tableBody');
  tbody.innerHTML = '';
  
  if (data.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8" style="text-align: center; padding: 30px; color: var(--text-secondary);">
          Nenhuma entrega atende aos filtros selecionados.
        </td>
      </tr>
    `;
    return;
  }

  data.forEach(d => {
    const atraso = d.dias_reais - d.prazo_dias;
    const isDelayed = atraso > 0;
    
    let statusClass = 'badge-success';
    let statusText = 'No Prazo';
    let priorityClass = 'success';
    let priorityText = 'Baixa';
    
    if (isDelayed) {
      if (atraso <= 4) {
        statusClass = 'badge-warning';
        statusText = 'Atrasado';
        priorityClass = 'warning';
        priorityText = 'Média';
      } else {
        statusClass = 'badge-danger';
        statusText = 'Crítico';
        priorityClass = 'critical';
        priorityText = 'Crítica';
      }
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="font-weight: 700; color: var(--color-primary);">#${d.id_entrega}</td>
      <td style="font-weight: 600;">${d.transportadora}</td>
      <td>${d.regiao}</td>
      <td style="text-align: center;">${d.prazo_dias}d</td>
      <td style="text-align: center;">${d.dias_reais}d</td>
      <td style="text-align: center; font-weight: 700; color: ${isDelayed ? 'var(--color-danger)' : 'var(--text-secondary)'};">
        ${isDelayed ? `+${atraso}d` : '0d'}
      </td>
      <td>
        <span class="badge ${statusClass}">
          <span class="priority-dot ${priorityClass}"></span>
          ${statusText} (${priorityText})
        </span>
      </td>
      <td>
        <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem;" onclick="triggerAction(${d.id_entrega}, '${d.transportadora}', ${atraso})">
          ${isDelayed && atraso > 4 ? '⚠️ Acionar' : 'Ver Detalhes'}
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Ação interativa ao clicar nos botões da tabela
function triggerAction(id, transportadora, atraso) {
  if (atraso > 4) {
    showNotification(`⚠️ ALERTA ENVIADO: Transportadora ${transportadora} notificada imediatamente para reverter atraso crítico da entrega #${id}!`);
  } else {
    showNotification(`Visualizando ficha operacional da entrega #${id} (${transportadora}).`);
  }
}

// 11. RENDERIZAÇÃO DOS GRÁFICOS (CHART.JS)
function renderCharts(data) {
  // Paletas de Cores dinâmicas para os gráficos dependendo do tema escuro/claro
  const isDark = currentTheme === 'dark';
  const gridColor = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(15, 23, 42, 0.08)';
  const labelColor = isDark ? '#94a3b8' : '#64748b';
  const titleColor = isDark ? '#f8fafc' : '#1e293b';

  // --- GRÁFICO 1: TRANSPORTADORAS ---
  // Agrupar dados por transportadora: total e atrasadas
  const carrierStats = {};
  // Inicializa transportadoras conhecidas para garantir que apareçam
  ['RotaMax', 'ViaCargo', 'FlashLog'].forEach(c => {
    carrierStats[c] = { total: 0, delayed: 0 };
  });

  data.forEach(d => {
    if (!carrierStats[d.transportadora]) {
      carrierStats[d.transportadora] = { total: 0, delayed: 0 };
    }
    carrierStats[d.transportadora].total++;
    if (d.dias_reais > d.prazo_dias) {
      carrierStats[d.transportadora].delayed++;
    }
  });

  const carriers = Object.keys(carrierStats);
  const totalList = carriers.map(c => carrierStats[c].total);
  const delayedList = carriers.map(c => carrierStats[c].delayed);

  if (chartCarrierInstance) {
    chartCarrierInstance.destroy();
  }

  const ctxCarrier = document.getElementById('chartCarrier').getContext('2d');
  chartCarrierInstance = new Chart(ctxCarrier, {
    type: 'bar',
    data: {
      labels: carriers,
      datasets: [
        {
          label: 'Total de Entregas',
          data: totalList,
          backgroundColor: isDark ? 'rgba(129, 140, 248, 0.65)' : 'rgba(99, 102, 241, 0.7)',
          borderColor: 'rgba(99, 102, 241, 1)',
          borderWidth: 1.5,
          borderRadius: 6
        },
        {
          label: 'Entregas com Atraso',
          data: delayedList,
          backgroundColor: isDark ? 'rgba(248, 113, 113, 0.7)' : 'rgba(239, 68, 68, 0.75)',
          borderColor: 'rgba(239, 68, 68, 1)',
          borderWidth: 1.5,
          borderRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: { color: labelColor, font: { family: 'Inter', weight: '500' } }
        },
        tooltip: {
          backgroundColor: isDark ? '#1e293b' : '#ffffff',
          titleColor: titleColor,
          bodyColor: labelColor,
          borderColor: gridColor,
          borderWidth: 1,
          cornerRadius: 8,
          padding: 10
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: labelColor }
        },
        y: {
          grid: { color: gridColor },
          ticks: { color: labelColor, stepSize: 1 },
          suggestedMax: 5
        }
      }
    }
  });


  // --- GRÁFICO 2: ATRASO MÉDIO POR REGIÃO ---
  // Agrupar dados por região
  const regionStats = {};
  data.forEach(d => {
    if (!regionStats[d.regiao]) {
      regionStats[d.regiao] = { totalDelay: 0, count: 0 };
    }
    const delay = d.dias_reais - d.prazo_dias;
    // O problema pede a média de atraso (dias que passaram do prazo)
    regionStats[d.regiao].totalDelay += Math.max(0, delay);
    regionStats[d.regiao].count++;
  });

  const regions = Object.keys(regionStats);
  const avgRegionDelay = regions.map(r => {
    return regionStats[r].count > 0 ? (regionStats[r].totalDelay / regionStats[r].count) : 0;
  });

  if (chartRegionInstance) {
    chartRegionInstance.destroy();
  }

  const ctxRegion = document.getElementById('chartRegion').getContext('2d');
  chartRegionInstance = new Chart(ctxRegion, {
    type: 'bar', // Barra horizontal
    data: {
      labels: regions,
      datasets: [{
        label: 'Atraso Médio (Dias)',
        data: avgRegionDelay,
        backgroundColor: 'rgba(245, 158, 11, 0.7)',
        borderColor: 'rgba(245, 158, 11, 1)',
        borderWidth: 1.5,
        borderRadius: 6
      }]
    },
    options: {
      indexAxis: 'y', // Barra Horizontal
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: isDark ? '#1e293b' : '#ffffff',
          titleColor: titleColor,
          bodyColor: labelColor,
          borderColor: gridColor,
          borderWidth: 1,
          cornerRadius: 8
        }
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: { color: labelColor },
          title: { display: true, text: 'Dias de Atraso', color: labelColor }
        },
        y: {
          grid: { display: false },
          ticks: { color: labelColor }
        }
      }
    }
  });


  // --- GRÁFICO 3: DISTRIBUIÇÃO DE STATUS ---
  let statusCounts = [0, 0, 0]; // [No Prazo, Atraso Moderado, Atraso Crítico]
  data.forEach(d => {
    const delay = d.dias_reais - d.prazo_dias;
    if (delay <= 0) statusCounts[0]++;
    else if (delay <= 4) statusCounts[1]++;
    else statusCounts[2]++;
  });

  if (chartStatusInstance) {
    chartStatusInstance.destroy();
  }

  const ctxStatus = document.getElementById('chartStatus').getContext('2d');
  chartStatusInstance = new Chart(ctxStatus, {
    type: 'doughnut',
    data: {
      labels: ['No Prazo', 'Atraso Moderado', 'Atraso Crítico'],
      datasets: [{
        data: statusCounts,
        backgroundColor: [
          'rgba(16, 185, 129, 0.75)', // Success
          'rgba(245, 158, 11, 0.75)', // Warning
          'rgba(239, 68, 68, 0.75)'   // Danger
        ],
        borderColor: isDark ? '#111827' : '#ffffff',
        borderWidth: 2,
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right',
          labels: { color: labelColor, font: { family: 'Inter', weight: '600', size: 11 } }
        },
        tooltip: {
          backgroundColor: isDark ? '#1e293b' : '#ffffff',
          titleColor: titleColor,
          bodyColor: labelColor,
          borderColor: gridColor,
          borderWidth: 1,
          cornerRadius: 8
        }
      },
      cutout: '65%'
    }
  });
}

// 12. NOTIFICAÇÕES TOAST PARA SIMULAÇÕES E ALERTAS
function showNotification(message) {
  // Remove toast anterior se existir
  const oldToast = document.querySelector('.toast-notification');
  if (oldToast) oldToast.remove();

  const toast = document.createElement('div');
  toast.className = 'toast-notification';
  toast.innerText = message;
  
  // Estilo inline para evitar conflitos, mas integrando com a identidade visual
  Object.assign(toast.style, {
    position: 'fixed',
    bottom: '24px',
    right: '24px',
    backgroundColor: 'var(--text-primary)',
    color: 'var(--text-inverse)',
    padding: '14px 24px',
    borderRadius: '10px',
    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)',
    fontWeight: '600',
    fontSize: '0.875rem',
    zIndex: '9999',
    opacity: '0',
    transform: 'translateY(20px)',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    border: '1px solid var(--card-border)'
  });

  document.body.appendChild(toast);

  // Forçar reflow para animar
  setTimeout(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
  }, 10);

  // Desaparecer após 4.5 segundos
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)';
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}
