# LogiTrack | Dashboard de Monitoramento Logístico Inteligente

Este projeto consiste em um dashboard interativo moderno desenvolvido com **HTML5 semântico, CSS3 (com Glassmorphism e suporte a temas Light/Dark) e JavaScript puro**, integrado à biblioteca **Chart.js** para visualizações analíticas de alta performance.

A aplicação foi criada sob medida para monitorar atrasos de entregas de forma ágil, comparando o desempenho de parceiros operacionais (transportadoras), mapeando gargalos regionais e fornecendo mecanismos de ação em tempo real.

---

## 🚀 Como Executar o Projeto Localmente

O dashboard é totalmente autônomo e pode ser aberto diretamente no navegador. No entanto, para fins de desenvolvimento com recarregamento em tempo real (Live Reloading), incluímos um servidor estático local.

### Pré-requisitos
- Node.js instalado (versão 14 ou superior)

### Instruções
1. Abra um terminal no diretório do projeto: `C:\Users\Win 10\.gemini\antigravity\scratch\logistic-dashboard`
2. Instale as dependências (servidor de desenvolvimento):
   ```bash
   npm install
   ```
3. Execute o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
4. O dashboard será aberto automaticamente no seu navegador padrão em: `http://localhost:3000`

---

## ☁️ Instruções para Publicação (Link de Acesso dos Avaliadores)

Conforme os **requisitos críticos** do desafio, o dashboard deve possuir um link de acesso público e liberado, sem necessidade de solicitação de permissão. 

Como o dashboard foi estruturado como uma aplicação web estática de alto desempenho (HTML/CSS/JS puros), ele pode ser hospedado **gratuitamente** em menos de 1 minuto em plataformas globais de hospedagem estática. 

### Opção 1: Netlify (Recomendado - Arrastar e Soltar)
1. Acesse [Netlify Drop](https://app.netlify.com/drop).
2. Arraste a pasta `logistic-dashboard` inteira para a área de upload no navegador.
3. Em segundos, o Netlify gerará um link público funcional (ex: `https://logitrack-desafio.netlify.app`).

### Opção 2: Vercel CLI (Via Terminal)
1. Instale a ferramenta Vercel globalmente: `npm install -g vercel`
2. No diretório do projeto, execute: `vercel`
3. Siga os passos rápidos no terminal para criar o projeto e obter o link de acesso público.

---

## 🧠 Explicação da Lógica Utilizada (Respostas ao Desafio)

### 1. Critério de Identificação de Atraso
Uma entrega é considerada atrasada quando o tempo real de trânsito supera a janela de prazo acordada:
$$\text{Atraso (Dias)} = \text{dias\_reais} - \text{prazo\_dias}$$
- Se $\text{Atraso} > 0$, a entrega está **Atrasada**.
- Se $\text{Atraso} \le 0$, a entrega está **No Prazo**.

No conjunto de dados original de **10 entregas**, identificamos que **7 entregas sofreram atraso**, resultando em uma taxa de atraso operacional de **70%**.

### 2. Priorização Visual e Criticidade (Tomada de Decisão)
Para evitar a fadiga de alarmes e focar nos problemas mais graves, classificamos os desvios em três níveis de prioridade operacional:
- **No Prazo** (Verde - Baixa Prioridade): Entregas concluídas dentro do prazo contratado.
- **Atraso Moderado** (Laranja - Média Prioridade): Entregas com atraso de **1 a 4 dias** em relação ao prazo.
- **Atraso Crítico** (Vermelho - Alta Prioridade): Entregas com atraso **superior a 4 dias**.
  - *Ação Operacional:* Na tabela, entregas críticas recebem um alerta piscante automático e habilitam o botão **"⚠️ Acionar"** para que o gestor envie um alerta direto à transportadora parceira em tempo real.

### 3. Comparativo de Performance por Transportadora
O dashboard expõe graficamente o volume de entregas e o total de atrasados por parceiro:
- **ViaCargo**: 4 entregas realizadas, **3 atrasadas (75% de taxa de atraso)**, acumulando 9 dias de atraso. Embora possua a maior taxa de atraso, o desvio médio é moderado.
- **RotaMax**: 3 entregas realizadas, **2 atrasadas (66.7% de taxa de atraso)**, acumulando 7 dias de atraso.
- **FlashLog**: 3 entregas realizadas, **2 atrasadas (66.7% de taxa de atraso)**, acumulando 12 dias de atraso. **Destaque Crítico:** A FlashLog possui o maior tempo médio de atraso por entrega atrasada (**6.0 dias de atraso médio**), sendo a transportadora mais problemática em termos de severidade.

### 4. Análise Geográfica (Regiões Críticas)
Mapeamento de atraso por região geográfica (média de dias de atraso das entregas na região):
- **Nordeste**: 4.5 dias de atraso médio (Atraso Crítico).
- **Centro-Oeste**: 4.0 dias de atraso médio (Atraso Crítico).
- **Sul**: 3.3 dias de atraso médio.
- **Sudeste**: 2.5 dias de atraso médio.
- **Norte**: 0.0 dias de atraso médio (Todas entregas no prazo).

### 5. Recursos de Interação no Painel
- **Filtros Dinâmicos**: Permite filtrar instantaneamente por Transportadora, Região Geográfica e nível de Gravidade do Atraso.
- **Gráficos Responsivos**: Gráfico de colunas de transportadora, barras horizontais de regiões e donut de status atualizam suas proporções instantaneamente em resposta aos filtros e novas simulações.
- **Simulador de Entregas**: Permite que o usuário insira novas entregas informando ID, Transportadora, Região, Prazo e Dias Reais. Toda a base estatística do dashboard se recalcula dinamicamente em tempo real ao adicionar um novo registro.
- **Ordenação Dinâmica**: Ordenação rápida de qualquer coluna da tabela (por exemplo, clicando em "Atraso (Dias)" para listar as piores entregas no topo).
